public class notinSGException extends Exception {
    public notinSGException(){

    }
}
