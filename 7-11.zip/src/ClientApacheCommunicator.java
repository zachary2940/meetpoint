public class ClientApacheCommunicator {
}
