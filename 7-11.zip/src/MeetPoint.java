import java.io.Serializable;

public class MeetPoint extends Location implements Serializable {

    private String type;
    private double travelDuration;
    private String meetPointImage;

    public MeetPoint(){}
    public MeetPoint(String name, double[] coordinates, String type, double travelDuration, String meetPointImage){
        super(name, coordinates);
        this.type=type;
        this.travelDuration=travelDuration;
        this.meetPointImage=meetPointImage;
    }

    public String getType(){
        return type;
    }

    public double getTravelDuration() {
        return travelDuration;
    }

    public String getMeetPointImage(){
        return meetPointImage;
    }

    public void setType(String newType){
        type=newType;
    }

    public void setTravelDuration(double newDuration){
        travelDuration=newDuration;
    }

    public void setMeetPointImage(String newImage) {
        meetPointImage=newImage;
    }
}
