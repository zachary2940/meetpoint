import java.util.ArrayList;

public class UserTester {

    public static void main(String[] args) {



        /*
        readme:
        this is to test ReadWriteToCsv.SessionsLogCsvWriter and ReadWriteToCsv.SessionsLogCsvParser.
        currently I'm parsing "data.csv" into ReadWriteToCsv.SessionsLogCsvParser, and using ReadWriteToCsv.SessionsLogCsvWriter to write the data immediately out to
        "New Data.csv"

        Also, I saved the parsed data from "data.csv" into a ArrayList<session> at the very end of the code,
        so you can use that to try to print some specific data from the session arraylist.

        */

        //calling the csv writer

        UserDetailsCsvWriter.writeToCSV(UserDetailsCsvParser.readFromCSV());

        ArrayList<UserDetails> users = UserDetailsCsvParser.readFromCSV();

        //test the output
        System.out.println(users.get(0).getName());


    }
}
