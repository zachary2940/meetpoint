

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class SessionsLogCsvWriter {

    private static StringBuilder sb = new StringBuilder();

    public static void writeToCSV(ArrayList<Session> list) {
        PrintWriter pw = null;
        try {
            pw = new PrintWriter(new File("NewData.csv"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        //things to append
        //session: String sessionID, String title, Location[] startLocations, String[] prefTravelModes, double userID
        //Location: String name, double[] coordinates
        for (int a = 0; a < list.size(); a++) {
            //SessionID
            log(list.get(a).getSessionID());
            //Title
            log(SpaceUnderscoreParser.toUnderscore(list.get(a).getTitle()));

            //StartLocations
            for (int i = 0; i < list.get(a).getStartLocations().length; i++) {
                log(SpaceUnderscoreParser.toUnderscore(list.get(a).getStartLocations()[i].getName()));
                for (int j = 0; j < 2; j++) {
                    log(String.valueOf(list.get(a).getStartLocations()[i].getCoordinates()[j]));
                }
            }
            //PrefTravelModes
            for (int i = 0; i < list.get(a).getPrefTravelModes().length; i++) {
                log(SpaceUnderscoreParser.toUnderscore(list.get(a).getPrefTravelModes()[i]));
            }
            //UserIDs
            for (int i = 0; i < list.get(a).getUserIDs().length; i++) {
                log(String.valueOf(list.get(a).getUserIDs()[i]));
            }
            //NumOfUsers
            log(String.valueOf(list.get(a).getNumOfUsers()));
            //MeetPoint[5]
            //String name, double[] coordinates, String type, double travelDuration, String meetPointImage
            if (list.get(a).getCalculated()) {
                for (int i = 0; i < list.get(a).getMeetPoints().length; i++) {
                    log(SpaceUnderscoreParser.toUnderscore(list.get(a).getMeetPoints()[i].getName()));
                    for (int j = 0; j < list.get(a).getMeetPoints()[i].getCoordinates().length; j++) {
                        log(String.valueOf(list.get(a).getMeetPoints()[i].getCoordinates()[j]));
                    }
                    log(SpaceUnderscoreParser.toUnderscore(list.get(a).getMeetPoints()[i].getType()));
                    log(String.valueOf(list.get(a).getMeetPoints()[i].getTravelDuration()));
                    log(list.get(a).getMeetPoints()[i].getMeetPointImage());
                }
                //ChosenMeetPoint
                log(SpaceUnderscoreParser.toUnderscore(list.get(a).getChosenMeetPoint().getName()));
                for (int j = 0; j < list.get(a).getChosenMeetPoint().getCoordinates().length; j++) {
                    log(String.valueOf(list.get(a).getChosenMeetPoint().getCoordinates()[j]));
                }
                log(SpaceUnderscoreParser.toUnderscore(list.get(a).getChosenMeetPoint().getType()));
                log(String.valueOf(list.get(a).getChosenMeetPoint().getTravelDuration()));
                log(list.get(a).getChosenMeetPoint().getMeetPointImage());
            } else {
                for (int i = 0; i < 36; i++) {
                    log("null");
                }
            }
            //prefLocationType
            log(SpaceUnderscoreParser.toUnderscore(list.get(a).getPrefLocationType()));
            //calculated
            log(String.valueOf(list.get(a).getCalculated()));
            //enter to next line for next session
            sb.append('\n');
            System.out.println("finished a line");
        }
        pw.write(sb.toString());
        pw.close();
    }

    private static void log (String string){
        sb.append(string);
        sb.append(',');
    }
}
