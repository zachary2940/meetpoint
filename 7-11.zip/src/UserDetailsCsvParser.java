

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class UserDetailsCsvParser {

    public static ArrayList<UserDetails> readFromCSV() {
        String fileName = "datauser.csv";
        File file = new File(fileName);
        // this gives you a 2-dimensional array of strings
        ArrayList<ArrayList<String>> lines = new ArrayList<>();
        Scanner inputStream;

        try {
            inputStream = new Scanner(file);

            while (inputStream.hasNext()) {
                String line = inputStream.next();
                ArrayList<String> values = new ArrayList<>(Arrays.asList(line.split(",")));
                // this adds the currently parsed line to the 2-dimensional string array
                lines.add(values);
            }
            inputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        ArrayList<UserDetails> list = new ArrayList<>();

        for (int i = 0; i < lines.size(); i++) {

            //String name, Double userID, Location prefStartLocation, String prefTravelMode, ArrayList<String> sessions

            //name
            String name = SpaceUnderscoreParser.toSpace(lines.get(i).get(0));
            //userID
            double userID = Double.valueOf(lines.get(i).get(1));
            //prefStartLocation
            String locationname = SpaceUnderscoreParser.toSpace(lines.get(i).get(2));
            double[] coordinates = {Double.valueOf(lines.get(i).get(3)), Double.valueOf(lines.get(i).get(4))};
            Location prefStartLocation = new Location(locationname, coordinates);
            //prefTravelMode
            String prefTravelMode = SpaceUnderscoreParser.toSpace(lines.get(i).get(5));
            //sessions

            ArrayList<String> sessions = new ArrayList<>();
            UserDetails user = new UserDetails();

            if (6==lines.get(i).size()) {
                user = new UserDetails(name,userID,prefStartLocation,prefTravelMode,sessions);
            } else {
                for (int j = 6; j < lines.get(i).size(); j++){
                    String session = lines.get(i).get(j);
                    sessions.add(session);
                }
                user = new UserDetails(name,userID,prefStartLocation,prefTravelMode,sessions);
            }


            list.add(user);

        }
        return list;
    }
}
