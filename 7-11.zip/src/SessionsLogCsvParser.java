

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class SessionsLogCsvParser {

    public static ArrayList<Session> readFromCSV() {
        String fileName = "data.csv";
        File file = new File(fileName);
        // this gives you a 2-dimensional array of strings
        ArrayList<ArrayList<String>> lines = new ArrayList<>();
        Scanner inputStream;

        try {
            inputStream = new Scanner(file);

            while (inputStream.hasNext()) {
                String line = inputStream.next();
                ArrayList<String> values = new ArrayList<>(Arrays.asList(line.split(",")));
                // this adds the currently parsed line to the 2-dimensional string array
                lines.add(values);
            }
            inputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        ArrayList<Session> list = new ArrayList<>();

        for (int i = 0; i < lines.size(); i++) {
            //    private String sessionID;
            //    private String title;
            //    private Location[] startLocations;
            //    private String[] prefTravelModes;
            //    private MeetPoint[] meetPoints;
            //    private MeetPoint chosenMeetPoint;
            //    private String prefLocationType;
            //    private double[] userIDs;
            //    private int numOfUsers;
            //    private boolean calculated;

            //sessionID
            String sessionID = lines.get(i).get(0);
            //title
            String title = SpaceUnderscoreParser.toSpace(lines.get(i).get(1));
            //startLocations
            Location[] startLocations = new Location[2];
            int count = 0;
            for (int j = 2; j <= 7; ) {
                String name = SpaceUnderscoreParser.toSpace(lines.get(i).get(j++));
                double[] coordinates = {Double.valueOf(lines.get(i).get(j++)), Double.valueOf(lines.get(i).get(j++))};
                Location location = new Location(name, coordinates);
                startLocations[count++] = location;

                //System.out.println(j);
                //System.out.println(String.valueOf(startLocations[count].getCoordinates()[0]));
            }
            //prefTravelModes
            String[] prefTravelModes = {SpaceUnderscoreParser.toSpace(lines.get(i).get(8)), SpaceUnderscoreParser.toSpace(lines.get(i).get(9))};
            //meetPoints and chosenMeetPoint
            //String name, double[] coordinates, String type, double travelDuration, String meetPointImage
            MeetPoint[] meetPoints = new MeetPoint[5];
            MeetPoint chosenMeetPoint = new MeetPoint();
            if (Boolean.valueOf(lines.get(i).get(50))) {
                count = 0;
                for (int j = 13; j <= 44; ) {
                    String name = SpaceUnderscoreParser.toSpace(lines.get(i).get(j++));
                    double[] coordinates = {Double.valueOf(lines.get(i).get(j++)), Double.valueOf(lines.get(i).get(j++))};
                    String type = SpaceUnderscoreParser.toSpace(lines.get(i).get(j++));
                    double travelDuration = Double.valueOf(lines.get(i).get(j++));
                    String meetPointImage = lines.get(i).get(j++);
                    MeetPoint meetPoint = new MeetPoint(name, coordinates, type, travelDuration, meetPointImage);
                    if (count <= 4) {
                        meetPoints[count++] = meetPoint;
                    } else {
                        chosenMeetPoint = meetPoint;
                    }

                }
            }
            //prefLocationType
            String prefLocationType = SpaceUnderscoreParser.toSpace(lines.get(i).get(49));
            //userIDs
            double[] userIDs = {Double.valueOf(lines.get(i).get(10)), Double.valueOf(lines.get(i).get(11))};
            //numOfUsers
            int numOfUsers = Integer.valueOf(lines.get(i).get(12));
            //calculated
            boolean calculated = Boolean.valueOf(lines.get(i).get(50));
            //putting it all together
            Session session = new Session();
            if (Boolean.valueOf(lines.get(i).get(50))) {
                //constructor for calculated session
                session = new Session(sessionID, title, startLocations, prefTravelModes, meetPoints, chosenMeetPoint, prefLocationType,
                        userIDs, numOfUsers, calculated);
            } else {
                //constructor for non-calculated session
                session = new Session(sessionID, title, startLocations, prefTravelModes, prefLocationType, userIDs, numOfUsers, calculated);
            }
            //add the session to the list
            list.add(session);
        }
        return list;
    }
}

