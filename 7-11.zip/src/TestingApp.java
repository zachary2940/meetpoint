import java.util.ArrayList;
import java.util.Scanner;

public class TestingApp {
    public static void main(String[] args) throws Exception{

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter first origin:");
        String origin1 = sc.next();
        System.out.println("Enter second origin:");
        String origin2 = sc.next();

        RouteOptimiser RO = new RouteOptimiser();
        ArrayList<MeetPoint> array;
        array = RO.findPossibleMP(origin1,origin2,"food_beverages","driving");
        RO.sortTravelDuration();

        System.out.println(array.get(1).getName());
        System.out.println(array.get(1).getTravelDuration());
        System.out.println(array.get(2).getName());
        System.out.println(array.get(2).getTravelDuration());
        System.out.println(array.get(3).getName());
        System.out.println(array.get(3).getTravelDuration());
        System.out.println(array.get(4).getName());
        System.out.println(array.get(4).getTravelDuration());
        System.out.println(array.get(5).getName());
        System.out.println(array.get(5).getTravelDuration());
    }
}