import java.util.ArrayList;
import java.util.Random;

public class SessionManager implements SessionDirectAccessObject {

    public static final SessionManager sm = new SessionManager();

    private static ArrayList<UserDetails> userArr;
    //new attribute in class
    private static SessionsLog sLog;

    public ArrayList<UserDetails> getUserArray() {
        return userArr;
    }

    public void updateUserArray(UserDetails newUser) {
        userArr.add(newUser);
    }

    //changed ArrayList<Double> to double. as we only sending one user.
    public Session createSession(String sessionTitle, double userID) {
        String sessID = generateSessionID();
        UserDetails thisUser = getUserDet(userID);
        Session s1 = new Session(sessID, sessionTitle, thisUser.getPrefStartLocation(), thisUser.getPrefTravelMode(), userID);
        thisUser.addSession(sessID);
        updateSessionsLog(s1);
        return s1;
    }

    public void updateSessionsLog(Session sess) {
        if (sLog.getSession(sess.getSessionID()) == null) {
            sLog.addSession(sess);
        }
    }

    public void joinSession(String sessID, double userID) {
        UserDetails secondUser = getUserDet(userID);
        secondUser.addSession(sessID);
        Session thisSess = sLog.getSession(sessID);
        if (thisSess.getNumOfUsers() == 1) {
            thisSess.setUserID(userID);
        }
        //need error method here?
    }

    //why is this method changing the UserDetail, shouldn't it be changing session detail. also missing paramters etc what am i changing to??
    public void changeADetail(double userID, String change) {
        UserDetails thisUser = getUserDet(userID);
        char a = change.charAt(4);
        if (a == 'T') {

        }
    }

    public void changeTravelMode(double userID, String newMode) {
        UserDetails thisUser = getUserDet(userID);
        thisUser.setPrefTravelMode(newMode);
    }

    public void calculateResult(String sessID) {
        Session thisSession = sLog.getSession(sessID);
        RouteOptimiser ro = new RouteOptimiser();
        //RO wants separate strings but this is an array.
        ArrayList<MeetPoint> possibleMPs = ro.findPossibleMP(thisSession.getStartLocations(), thisSession.getPrefLocationType(), thisSession.getPrefTravelModes());
        //sorting should happen within ro
        MeetPoint[] mpArr = possibleMPs.toArray(new MeetPoint[possibleMPs.size()]);
        thisSession.setMeetPoints(mpArr);
    }

    public void updateChosenMeetPoint(double userID, String sessID, MeetPoint bestResult) {
        Session newMP = sLog.getSession(sessID);
        newMP.setChosenMeetPoint(bestResult);
    }

    public void removeSession(String sessID, double userID) {
        UserDetails thisUser = getUserDet(userID);
        thisUser.removeSession(sessID);
        Session checkSess = sLog.getSession(sessID);
        checkSess.removeUserID(userID);
        if (checkSess.getNumOfUsers() == 0) {
            sLog.removeSession(checkSess);
        }
    }

    //added method to generate session ID.
    private String generateSessionID() {
        String alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        Random rand = new Random();

        char a = alpha.charAt(rand.nextInt(52));
        String b = Integer.toString(rand.nextInt(100));
        char c = alpha.charAt(rand.nextInt(52));
        String sessID = a + b + c;

        if (sLog.getSession(sessID) == null) {
            return sessID;
        }
        else {
            return generateSessionID();
        }
    }

    //adedd method to get UserDetails
    private UserDetails getUserDet(double userID) {
        for (UserDetails temp: userArr) {
            if (temp.getUserID() == userID) {
                return temp;
            }
        }
        return null;
    }

}
