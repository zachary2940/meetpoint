import java.util.ArrayList;

public interface SessionDirectAccessObject {

     ArrayList<UserDetails> getUserArray();
     void updateUserArray(UserDetails newUser);
     Session createSession(String sessionTitle, double userIDs);
     void updateSessionsLog(Session sess);
     void joinSession(String sessID, double userID);
     void changeADetail(double userID, String thingToChange);
     void changeTravelMode(double userID, String newMode);
     void removeSession(String sessionID, double userID);
}
