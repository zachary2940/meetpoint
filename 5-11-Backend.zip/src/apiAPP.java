import java.util.Scanner;

public class apiAPP {
    public static void main(String[] args) throws Exception
    {
        Scanner sc= new Scanner(System.in);
        MapsAPICommunicator mappie= new MapsAPICommunicator();
        STBAPICommunicator govie= new STBAPICommunicator();
        System.out.println("Enter your choice:");
        int choice=sc.nextInt();
        sc.nextLine();
        /*int option = 0;
        try {
            option = Integer.parseInt(input.nextLine());
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        String str1 = input.nextLine();*/
        switch (choice) {
            case 1:
                System.out.println("Enter address");
                String address = sc.nextLine();
                address = address.replaceAll("\\s+", "");
                mappie.getCoordinates(address);
                break;

            case 2:
                System.out.println("Enter origin, destination, meetpoint, mode of transport");
                String origin = sc.nextLine();
                origin = origin.replaceAll("\\s+", "");
                String destination = sc.nextLine();
                destination=destination.replaceAll("\\s+", "");
                String meetpoint = sc.nextLine();
                meetpoint=meetpoint.replaceAll("\\s+", "");
                String modeoftransport = sc.nextLine();
                modeoftransport=modeoftransport.replaceAll("\\s+", "");
                mappie.getImageURL(origin, destination, meetpoint, modeoftransport);
                break;

            case 3:
                System.out.println("Enter origin, meetpoint, mode of transport");
                String origin_2 = sc.nextLine();
                origin = origin_2.replaceAll("\\s+", "");
                String meetpoint_2 = sc.nextLine();
                meetpoint=meetpoint_2.replaceAll("\\s+", "");
                String modeoftransport_2 = sc.nextLine();
                modeoftransport=modeoftransport_2.replaceAll("\\s+", "");
                System.out.println(mappie.getDuration(origin, meetpoint, modeoftransport));
                break;

            case 4:
                System.out.println("Enter place, latitude, longitude, radius");
                String place=  sc.nextLine();
                String latitude=  sc.nextLine();
                String longitude=  sc.nextLine();
                String radius=  sc.nextLine();
                govie.getAddress(place, latitude, longitude, radius);
                break;
        }
    }
}

/**
 * Test Cases
 * 1.3725 , 103.9496 -- White Sands
 * 1.3404, 103.7090 -- JP
 * Orchard Point/Coordinates
 * 1.3015, 103.8406
 *
 * 1.3725 , 103.9496
 * 1.3404, 103.7090
 * 1.3015, 103.8406
 *
 * 1.3725 , 103.9496
 * 1.3390, 103.7298
 * 1.3404, 103.7090
 *
 * center of sg
 * 1.3521, 103.8198
 *
 *
 * https://maps.googleapis.com/maps/api/staticmap?size=400x400&markers=size:large|color:red|label:M|1.3521,103.8198&center=1.3521,%20103.8198&zoom=10.5&path=weight:4|color:red|enc:}bkGitmyRI\SKB[HO?[iB_BcAmAEc@Ga@iE?ApCMtAw@hDYrADZP`@vBv@z@TlDAjBNfAd@|EbBhRxBxEh@lB`@jCj@CXEb@QfA{@`Ao@Xo@LwBr@iBnAwCxDWLqFzFuCbDeAdBwE`K_F`L{CbHwG~QuFzO}@tDmDnTaBtI_CfIoAzDY`A_FdLaBbCMj@BfA\x@jA|@~AlA|A`BfCxDdE~HxDnHhB~BfCtBdEtB~MbDhJrBdW|FjKlCzJhEnRdI`ZxMhClAzIjCvJvC|HjCjCj@`BLrB?dCS|A]tDw@zCa@|DOjDNnDb@dDdA|BbAbChAjJlElEjDdCfCtBbC|A|BPXBFf@|@|B`FrCvHzD`Jj@bA|ApCrBxErBnEtAjBx@d@hB^jWt@`Fr@fDrA|AnApBfDlB`FbE~Ip@v@z@^fD|@^Zh@~@X~ABxACzBGvA_@pBoAnCgB~Bs@v@eErCcC~AKRcPxKgDjCiAfAuCpDeAdBeA~BkAtDcAbFaB`HaDnI[rAU`CA|AN~AdC~JxBvJPpB@zBc@dMSfFaAbVMxHNnP`@zL|@jD~A`ExBvEtB~EfAhEhFhVd@xDIhBg@fB_CjF_@hBG`ALzBb@fEJzCUrB_@hAiBnC{E|EwBlDkBnFcBjGiA`DuGrNuG~Nq@|BwAxHu@`C{@dBmFrGsLzM_LlMkHvHyOtNsFzE{GtGiCdCkCpDqAhBm@lAqAlFq@lGBhER~ClAvFr@jB|@jA|BfBvFvBtEnB|BlB~@bBjG|RxDvN`AzEn@fB|@xAzApApHtCdGvBnCpAhBrAdAhAnD|E`DfFrCxFdEdMnArEx@jEVfDElGYrCaAvEaAjCsFpLqFlLmS~b@kQn_@cKfT{AfDoAxDoAtGShF[jHw@fEm@fBmBnDqBjCiHxGyMbMmC|CyBbDgLbViAtCuBjI{@zF]nGL`JH~Bj@pF|@rEhBdGnAlDlCxEfHzLxA`CrGdLrKpQfAlBRB\\n@Tl@D^AbAk@nHgErBuALGNTxAdCn@jAl@x@TRfBh@lEnAj@v@Lr@^vAZNlAAxBObDi@tI{Bf@[v@iAb@_BGs@GQ{DaAcDy@_Co@sAu@s@aAo@oAu@oCg@m@m@[yAb@wDtBaGrDwBtAQJKYmCmEkCiEQYNInCgBlFcD`DqApF}@Z]Lk@cF}QqAuEmEkPsDsM]{CCUZIxACfADjBd@pAj@x@PnABxBWt@a@|AuC~AsBbBgAzIkEWk@S}ALoDn@}C&key=
 */
