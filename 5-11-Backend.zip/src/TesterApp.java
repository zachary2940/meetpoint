import java.util.ArrayList;

public class TesterApp {

    public static void main(String[] args) {



        /*
        readme:
        this is to test ReadWriteToCsv.SessionsLogCsvWriter and ReadWriteToCsv.SessionsLogCsvParser.
        currently I'm parsing "data.csv" into ReadWriteToCsv.SessionsLogCsvParser, and using ReadWriteToCsv.SessionsLogCsvWriter to write the data immediately out to
        "New Data.csv"

        Also, I saved the parsed data from "data.csv" into a ArrayList<session> at the very end of the code,
        so you can use that to try to print some specific data from the session arraylist.

        */

        //calling the csv writer

        SessionsLogCsvWriter.writeToCSV(SessionsLogCsvParser.readFromCSV());

        ArrayList<Session> sessionLog = SessionsLogCsvParser.readFromCSV();

        //test the output
        System.out.println(sessionLog.get(2).getTitle());


    }
}

    /*
    immediately below this is some code to create a testsession if you want, no longer in use currently:


        double[] coordinates1 = new double[2];
        coordinates1[0] = 12.34;
        coordinates1[1] = 23.44;

        double[] coordinates2 = new double[2];
        coordinates2[0] = 56.98;
        coordinates2[1] = 12.67;

        Location test1 = new Location("location1", coordinates1);
        Location test2 = new Location("location2", coordinates2);

        Location[] locationarrray = new Location[2];
        locationarrray[0] = test1;
        locationarrray[1] = test2;

        String[] travelarray = new String[2];
        travelarray[0] = "Bus";
        travelarray[1] = "Car";

        Session testSession = new Session(1234, "test", locationarrray, travelarray, 1234);

        //creating the MeetPoints and ChosenMeetPoint
        //String name, double[] coordinates, String type, double[] travelDurations, String meetPointImage

        double[] travelduration = new double[2];
        travelduration[0]=5.5;
        travelduration[1]=4.3;

        MeetPoint meetpoint1 = new MeetPoint("name",coordinates1,"Mall",travelduration,"thisurlisgreat.com");
        MeetPoint meetpoint2 = new MeetPoint("null",coordinates1,"Mall",travelduration,"thisurlisgreat.com");

        MeetPoint[] meetpointarray = new MeetPoint[5];
        meetpointarray[0] = meetpoint1;
        meetpointarray[1] = meetpoint1;
        meetpointarray[2] = meetpoint1;
        meetpointarray[3] = meetpoint1;
        meetpointarray[4] = meetpoint1;

        testSession.setMeetPoints(meetpointarray);
        testSession.setChosenMeetPoint(meetpoint1);
        testSession.setCalculated(true);
   */