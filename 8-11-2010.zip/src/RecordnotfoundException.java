
public class RecordnotfoundException extends Exception{
    public RecordnotfoundException(){
    }
}
