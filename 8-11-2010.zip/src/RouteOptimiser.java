

import org.json.JSONObject;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import static java.lang.Math.*;

public class RouteOptimiser {
    private ArrayList<MeetPoint> meetPointArrayList = new ArrayList<>();
    private STBAPICommunicator sAPI = new STBAPICommunicator();
    private MapsAPICommunicator mAPI = new MapsAPICommunicator();

    private double[] fetchDoubleCoordinates(String origin) throws Exception{
        return mAPI.getCoordinates(origin);
    }
    private String fetchStringCoordinates(String origin) throws Exception{
        double[] coordinates = mAPI.getCoordinates(origin);
        return coordinates[0] + "," + coordinates[1];
    }
    public double[] findMidPoint(String org1, String org2) throws Exception{

        double[] origin1 = fetchDoubleCoordinates(org1);
        double[] origin2 = fetchDoubleCoordinates(org2);

        double lon1 = origin1[1]*0.01745329251;
        double lat1 = origin1[0]*0.01745329251;
        double lon2 = origin2[1]*0.01745329251;
        double lat2 = origin2[0]*0.01745329251;
        double dLon = lon2 - lon1;

        double Bx = cos(lat2) * cos(dLon);
        double By = cos(lat2) * sin(dLon);
        double midlat3 = atan2(sin(lat1) + sin(lat2), sqrt((cos(lat1) + Bx) * (cos(lat1) + Bx) + By * By));
        double midlon3 = lon1 + atan2(By, cos(lat1) + Bx);

        double midpoint[];
        midpoint = new double[]{midlat3/0.01745329251,midlon3/0.01745329251};
        System.out.println(midpoint[0]);
        System.out.println(midpoint[1]);
        return midpoint;
    }
    private MeetPoint fetchMeetPoint(String destination, double destlat, double destlon, String origin1, String origin2, String prefTravelMode)throws Exception{
        MeetPoint mp = new MeetPoint();
        double[] coord = new double[]{destlat,destlon};
        mp.setCoordinates(coord);
        System.out.println(coord);
        mp.setName(destination);
        System.out.println(mp.getName());

        double duration = Double.valueOf(mAPI.getDuration(fetchStringCoordinates(origin1),String.valueOf(destlat),String.valueOf(destlon),prefTravelMode).replaceAll("\\D+","")) + Double.valueOf(mAPI.getDuration(fetchStringCoordinates(origin2),String.valueOf(destlat),String.valueOf(destlon),prefTravelMode).replaceAll("\\D+",""));
        mp.setTravelDuration(duration);
        System.out.println(mp.getTravelDuration());
        String dest = coord[0] + "," + coord[1];
        String url = mAPI.getImageURL(fetchStringCoordinates(origin1), fetchStringCoordinates(origin2), dest, prefTravelMode);
        mp.setMeetPointImage(url);
        System.out.println("fetch meetpoint ok");
        return mp;
    }
    public ArrayList<MeetPoint> findPossibleMP(String origin1, String origin2, String prefLocationType, String prefTravelMode)throws Exception{
        double[] midpoint = findMidPoint(origin1,origin2);
        int radius = 1000; //in metres
        ArrayList<JSONObject> possibleMP = new ArrayList<>();
        NumberFormat coordformat = new DecimalFormat("#0.000000");
        while (possibleMP.size() < 8){
            radius+=500;
            try{
                possibleMP = sAPI.getAddress(prefLocationType,coordformat.format(midpoint[0]),coordformat.format(midpoint[1]),String.valueOf(radius));
            } catch(RecordnotfoundException e){
                System.out.println("Exception not found");
            }
        }
        for (int i=0;i<possibleMP.size();i++){
            meetPointArrayList.add(
                    fetchMeetPoint(
                            possibleMP.get(i).getString("name"),
                            possibleMP.get(i).getDouble("latitude"),possibleMP.get(i).getDouble("longitude"),
                            origin1,
                            origin2,
                            prefTravelMode
                    )
            );

        }
        System.out.println("before");
        sortTravelDuration();
        System.out.println("travel duration works");
        return meetPointArrayList;
    }

    public void sortTravelDuration(){
        Collections.sort(meetPointArrayList, new CustomComparator());
    }

    class CustomComparator implements Comparator<MeetPoint> {
        public int compare(MeetPoint mp1, MeetPoint mp2) {
            return (int) (mp1.getTravelDuration() - mp2.getTravelDuration());
        }
    }

}
