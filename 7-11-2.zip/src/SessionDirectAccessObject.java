import java.util.ArrayList;

public interface SessionDirectAccessObject {

     ArrayList<UserDetails> getUserArray();
     void updateUserArray(UserDetails newUser);
     Session createSession(String sessionTitle, String userIDs);
     void updateSessionsLog(Session sess);
     void joinSession(String sessID, String userID);
     void changeADetail(String userID, String thingToChange);
     void changeTravelMode(String userID, String newMode);
     void removeSession(String sessionID, String userID);
}
