import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import static java.lang.Math.*;

public class RouteOptimiser {
    private ArrayList<MeetPoint> meetPointArrayList = new ArrayList<>();
    private STBAPICommunicator sAPI = new STBAPICommunicator();
    private MapsAPICommunicator mAPI = new MapsAPICommunicator();

    private double[] fetchDoubleCoordinates(String origin) throws Exception{
        return mAPI.getCoordinates(origin);
    }
    private String fetchStringCoordinates(String origin) throws Exception{
        double[] coordinates = mAPI.getCoordinates(origin);
        return coordinates[0] + "," + coordinates[1];
    }
    public double[] findMidPoint(String org1, String org2) throws Exception{

        double[] origin1 = fetchDoubleCoordinates(org1);
        double[] origin2 = fetchDoubleCoordinates(org2);

        double lon1 = origin1[1]*0.01745329251;
        double lat1 = origin1[0]*0.01745329251;
        double lon2 = origin2[1]*0.01745329251;
        double lat2 = origin2[0]*0.01745329251;
        double dLon = lon2 - lon1;

        double Bx = cos(lat2) * cos(dLon);
        double By = cos(lat2) * sin(dLon);
        double midlat3 = atan2(sin(lat1) + sin(lat2), sqrt((cos(lat1) + Bx) * (cos(lat1) + Bx) + By * By));
        double midlon3 = lon1 + atan2(By, cos(lat1) + Bx);

        double midpoint[];
        midpoint = new double[]{midlat3/0.01745329251,midlon3/0.01745329251};
        return midpoint;
    }
    private MeetPoint fetchMeetPoint(String destination, double destlat, double destlon, String origin1, String origin2, String prefTravelMode)throws Exception{
        MeetPoint mp = new MeetPoint();
        double[] coord = new double[]{destlat,destlon};
        mp.setCoordinates(coord);
        mp.setName(destination);
        double duration = Double.valueOf(mAPI.getDuration(fetchStringCoordinates(origin1),String.valueOf(destlat),String.valueOf(destlon),prefTravelMode).replaceAll("\\D+","")) + Double.valueOf(mAPI.getDuration(fetchStringCoordinates(origin2),String.valueOf(destlat),String.valueOf(destlon),prefTravelMode).replaceAll("\\D+",""));
        mp.setTravelDuration(duration);
        return mp;
    }
    public ArrayList<MeetPoint> findPossibleMP(String origin1, String origin2, String prefLocationType, String prefTravelMode)throws Exception{
        double[] midpoint = findMidPoint(origin1,origin2);
        int radius = 2000; //in metres
        List<JSONObject> possibleMP;
        NumberFormat coordformat = new DecimalFormat("#0.000000");
        possibleMP = sAPI.getAddress(prefLocationType,coordformat.format(midpoint[0]),coordformat.format(midpoint[1]),String.valueOf(radius));
        while (possibleMP.size() < 10){
            radius+=500;
            List<JSONObject> possibleMPcand;
            possibleMPcand = sAPI.getAddress(prefLocationType,String.valueOf(midpoint[0]),String.valueOf(midpoint[1]),String.valueOf(radius));
            possibleMP.addAll(possibleMPcand);
        }
        for (int i=0;i<possibleMP.size();i++){
            meetPointArrayList.add(i,fetchMeetPoint(possibleMP.get(i).getString("name"),possibleMP.get(i).getDouble("latitude"),possibleMP.get(i).getDouble("longitude"), origin1, origin2, prefTravelMode));
        }
        return meetPointArrayList;
    }

    public void sortTravelDuration(){
        Collections.sort(meetPointArrayList, new CustomComparator());
    }

    class CustomComparator implements Comparator<MeetPoint> {
        public int compare(MeetPoint mp1, MeetPoint mp2) {
            return (int) (mp1.getTravelDuration() - mp2.getTravelDuration());
        }
    }
}
