import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class UserDetailsCsvWriter {

    private static StringBuilder sb = new StringBuilder();

    public static void writeToCSV(ArrayList<UserDetails> list) {
        PrintWriter pw = null;
        try {
            pw = new PrintWriter(new File("UserNewData.csv"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        //things to append
        //String name, Double userID, Location prefStartLocation, String prefTravelMode, ArrayList<String> sessions
        for (int a = 0; a < list.size(); a++) {
            //name
            log(SpaceUnderscoreParser.toUnderscore(list.get(a).getName()));
            //userID
            log(String.valueOf(list.get(a).getUserID()));
            //prefStartLocation
            log(SpaceUnderscoreParser.toUnderscore(list.get(a).getPrefStartLocation().getName()));
            log(String.valueOf(list.get(a).getPrefStartLocation().getCoordinates()[0]));
            log(String.valueOf(list.get(a).getPrefStartLocation().getCoordinates()[1]));
            //prefTravelMode
            log(list.get(a).getPrefTravelMode());
            //sessions
            for(int i=0;i<list.get(a).getSessions().size();i++){
                log(list.get(a).getSessions().get(i));
            }

            //enter to next line for next UserDetails
            sb.append('\n');
            System.out.println("finished a user");
        }
        pw.write(sb.toString());
        pw.close();
    }

    private static void log (String string){
        sb.append(string);
        sb.append(',');
    }
}
