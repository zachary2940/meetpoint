

public class SpaceUnderscoreParser {

    public static String toUnderscore(String string) {
        String s = string;
        s=s.replace(' ','_');
        return s;
    }

    public static String toSpace(String string) {
        String s = string;
        s=s.replace('_',' ');
        return s;
    }


}
