import java.io.*;
import java.net.InetSocketAddress;
import java.util.ArrayList;

import com.sun.net.httpserver.Headers;
import jdk.nashorn.internal.runtime.ECMAException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONString;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

/**
 * do i need to keep refreshing
 */
public class ClientHTTPCommunicator {

    public static void main(String[] args) throws Exception {
        HttpServer server = HttpServer.create(new InetSocketAddress(8080), 0);
        System.out.println("Listening for connection on port 8080 ....");
        server.createContext("/meetpoint", new MyHandler());
        server.setExecutor(null); // creates a default executor
        server.start();
    }

    static class MyHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange t) throws IOException {
//            String response = "This is the response";
            System.out.println(t.getRemoteAddress() + " Server Connected");// prints out ip
            OutputStream out = t.getResponseBody(); //should i use printwriter here
//            out.write(response.getBytes()); //writes to the http page
//            System.out.println(t.getResponseBody());
//            out.close();
            //Headers h = t.getResponseHeaders();
            //h.add("Content-Type", "application/json");

            InputStreamReader isr = new InputStreamReader(t.getRequestBody(), "utf-8");
            BufferedReader br = new BufferedReader(isr);
            int b;
            StringBuilder buf = new StringBuilder(512); // From now on, the right way of moving from bytes to utf-8 characters:
            try {
                while ((b = br.read()) != -1) {
                    buf.append((char) b);
                }
            } catch (Exception e) {
                if (buf == null) {
                    System.out.println("shit");
                }
            }
//            System.out.println(buf);

            br.close();
            isr.close();
            String jsonstring = buf.toString(); //works for json
            JSONObject json = new JSONObject(jsonstring);
            System.out.println(json);
            String choice = json.getString("method");
//            System.out.println(choice);
            switch (choice) {
                case "updateUser":
                    String name = json.getString("name");
                    Double userId = json.getDouble("userId");
                    String defaultStartAddress = json.getString("defaultStartAddress");
                    String defaultTravelMode = json.getString("defaultTravelMode");
                    UserDetails user = new UserDetails(name, userId, new Location(defaultStartAddress), defaultTravelMode); //add and update is the same thing, will check if the user id is the same
                    System.out.println("Updated User");
                    SessionManager.sm.updateUserArray(user);
                    JSONObject userDetails = new JSONObject();
                    userDetails.put("result", "O");
                    t.sendResponseHeaders(200, userDetails.toString().length());
                    out.write(userDetails.toString().getBytes());
                    //System.out.println(t.getResponseBody().toString());
                    //out.close();
                    break;

                case "getSessions": //might have null pointer for get sessions
                    ArrayList<Session> sessions = SessionsLog.getSessions();//json.getDouble("userId"));
                    JSONObject OverLordList = new JSONObject();
                    OverLordList.put("result", "O");
                    System.out.println("Retrieved Sessions");
                    JSONArray sessionArray = new JSONArray();
                    for(int i=0; i<sessions.size();i++){
                                JSONObject sessionObject = new JSONObject();
                                    Session sesh = sessions.get(i); // getting session object
                                    String sessionId = sesh.getSessionID();
                                    String title = sesh.getTitle();
                                    MeetPoint chosenMeetPoint = sesh.getChosenMeetPoint();
                                    int meetpointIndex = 0;  //sesh.getChosenMeetPointIndex();
                                    sessionObject.put("sessionId" , sessionId);
                                    sessionObject.put("title", title);
                                    sessionObject.put("chosenMeetpoint", meetpointIndex);
                                        JSONArray meetpointArray = new JSONArray();
                                        JSONObject meetpointObject = new JSONObject();
                                        MeetPoint[] meetPoints = sesh.getMeetPoints();
                                        for(int j=0; j<meetPoints.length; j++) {
                                            MeetPoint meetPoint = meetPoints[j];
                                            meetpointObject.put("routeImage", meetPoint.getMeetPointImage());
                                            meetpointObject.put("name", meetPoint.getName());
                                            JSONObject coordinates = new JSONObject();
                                                double[] coord = meetPoint.getCoordinates();
                                                double lat = coord[0];
                                                double lon = coord[1];
                                                coordinates.put("lat", lat);
                                                coordinates.put("lon", lon);
                                            meetpointObject.put("coordinates", coordinates);
                                            meetpointArray.put(meetpointObject);
                                        }
                        sessionObject.put("meetpoints", meetpointArray);
                        sessionArray.put(sessionObject);
                    }
                    OverLordList.put("sessions", sessionArray);
                    print(OverLordList);
                    t.sendResponseHeaders(200, OverLordList.toString().length());
                    out.write(OverLordList.toString().getBytes());
                    break;

//                case "createSession":
//                    Double userId_3 = json.getDouble("userId");
//                    String sessionTitle = json.getString("sessionTitle");
//                    Session newSession = SessionManager.sm.createSession(sessionTitle, userId_3);
//                    String sessionId = newSession.getSessionID();
//                    UserDetails user_2 = SessionManager.sm.findUserDetail(userId_3);
//                    String name_2 = user_2.getName();
//                    String prefTravelMode = user_2.getPrefTravelMode();
//                    String prefStartLocation = user_2.getPrefStartLocation().getName();
//                    user_2.addSession(sessionTitle);
//                    JSONObject sessionJson = new JSONObject();
//                    sessionJson.put("result", "O");
//                    sessionJson.put("sessionId", sessionId);
//                    sessionJson.put("U1N", name_2);
//                    sessionJson.put("U1T", prefTravelMode);
//                    sessionJson.put("U1A", prefStartLocation);
//                    t.sendResponseHeaders(200, sessionJson.toString().length());
//                    out.write(sessionJson.toString().getBytes());
//                    break;

//                case "joinSession":
//                    Double userId_3 = json.getDouble("userId");
//                    String sessionTitle = json.getString("sessionTitle");
//                    Session newSession = SessionManager.sm.createSession(sessionTitle, userId_3);
//                    String sessionId = newSession.getSessionID();
//                    UserDetails user_2 = SessionManager.sm.findUserDetail(userId_3);
//                    String name_2 = user_2.getName();
//                    String prefTravelMode = user_2.getPrefTravelMode();
//                    String prefStartLocation = user_2.getPrefStartLocation().getName();
//                    user_2.addSession(sessionTitle);
//                    JSONObject sessionJson = new JSONObject();
//                    sessionJson.put("result", "O");
//                    sessionJson.put("sessionId", sessionId);
//                    sessionJson.put("U1N", name_2);
//                    sessionJson.put("U1T", prefTravelMode);
//                    sessionJson.put("U1A", prefStartLocation);
//                    t.sendResponseHeaders(200, sessionJson.toString().length());
//                    out.write(sessionJson.toString().getBytes())
//                    break;

                case "deleteSession":
                    String sessionId_1 = json.getString("sessionId");
                    double userId_4 = json.getDouble("userId");
                    SessionManager.sm.removeSession(sessionId_1, userId_4);
                    JSONObject deleteSession = new JSONObject();
                    deleteSession.put("result", "O");
                    t.sendResponseHeaders(200, deleteSession.toString().length());
                    out.write(deleteSession.toString().getBytes());
                    break;

                case "calculate":
                    String sessionId_2 = json.getString("sessionId"); // how to get correct session
                    Session calculatedSession = SessionsLog.getSession(sessionId_2);
                    MeetPoint[] meetPoints = calculatedSession.getMeetPoints();
                    JSONObject meetpointList = new JSONObject();
                    JSONArray meetpointArray = new JSONArray();
                    for(int i=0; i<meetPoints.length; i++) {
                        JSONObject meetpointObject = new JSONObject();
                        MeetPoint meetPoint = meetPoints[i];
                        meetpointObject.put("routeImage", meetPoint.getMeetPointImage());
                        meetpointObject.put("name", meetPoint.getName());
                        JSONObject coordinates = new JSONObject();
                        double[] coord = meetPoint.getCoordinates();
                        double lat = coord[0];
                        double lon = coord[1];
                        coordinates.put("lat", lat);
                        coordinates.put("lon", lon);
                        meetpointObject.put("coordinates", coordinates);
                        meetpointArray.put(meetpointObject);
                    }
                    meetpointList.put("result", "O");
                    meetpointList.put("meetpoints", meetpointArray);
                    break;

                case "editSession":
                    String sessionId_3 = json.getString("sessionId");
                    double userId_5 = json.getDouble("userId");

                }

            }
        }

// The resulting string is: buf.toString()
// and the number of BYTES (not utf-8 characters) from the body is: buf.length()




    static void print(Object o) {
        System.out.println(o);
    }
}
//    }



/**
 * http://localhost:8080/meetpoint
 *
 * JSONObject obj = new JSONObject();
 * JSONArray arr = new JSONArray();
 *
 *
 * for(int i = 0 ; i< list.size() ; i++)
 * {
 *     p = list.get(i);
 *
 *     obj.put("id", p.getId());
 *     obj.put("title", p.getTitle());
 *     obj.put("date". new MyDateFormatter().getStringFromDateDifference(p.getCreationDate()));
 *     obj.put("txt", getTrimmedText(p.getText()));
 *
 *     arr.put(obj);
 *
 *     obj = new JSONObject();
 * }
 */