//import java.util.ArrayList;
public class Session {
    private String sessionID;
    private String title;
    private Location[] startLocations;
    private String[] prefTravelModes;
    private MeetPoint[] meetPoints;
    private MeetPoint chosenMeetPoint;
    private String prefLocationType;
    private double[] userIDs;
    private int numOfUsers;
    private boolean calculated;

    public Session(){}
    //constructor for create session
    public Session(String sessionID, String title, Location startLocation, String prefTravelMode, double userID){
        this.sessionID=sessionID;
        this.title=title;
        this.startLocations = new Location[2];
        this.startLocations[0]=startLocation;
        this.prefTravelModes = new String[2];
        this.prefTravelModes[0]=prefTravelMode;
        this.userIDs=new double[2];
        this.userIDs[0]=userID;
        this.numOfUsers=1;
        this.calculated = false;
        this.meetPoints = new MeetPoint[5];
    }

    //constructor for csv parsing - calculated
    public Session(String sessionID, String title, Location[] startLocations, String[] prefTravelModes, MeetPoint[] meetPoints,
                   MeetPoint chosenMeetPoint, String prefLocationType, double[] userIDs, int numOfUsers, boolean calculated){
        this.sessionID=sessionID;
        this.title=title;
        this.startLocations = new Location[2];
        this.startLocations=startLocations;
        this.prefTravelModes = new String[2];
        this.prefTravelModes=prefTravelModes;
        this.meetPoints = new MeetPoint[5];
        this.meetPoints = meetPoints;
        this.chosenMeetPoint = chosenMeetPoint;
        this.prefLocationType = prefLocationType;
        this.userIDs=new double[2];
        this.userIDs = userIDs;
        this.numOfUsers = numOfUsers;
        this.calculated = calculated;
    }

    //constructor for csv parsing - not calculated
    public Session(String sessionID, String title, Location[] startLocations, String[] prefTravelModes, String prefLocationType,
                   double[] userIDs, int numOfUsers, boolean calculated){
        this.sessionID=sessionID;
        this.title=title;
        this.startLocations = new Location[2];
        this.startLocations=startLocations;
        this.prefTravelModes = new String[2];
        this.prefTravelModes=prefTravelModes;
        this.meetPoints = new MeetPoint[5];
        this.prefLocationType = prefLocationType;
        this.userIDs=new double[2];
        this.userIDs = userIDs;
        this.numOfUsers = numOfUsers;
        this.calculated = calculated;
    }


    public String getSessionID(){
        return sessionID;
    }
    public String getTitle(){
        return title;
    }
    public Location[] getStartLocations(){
        return startLocations;
    }
    public String[] getPrefTravelModes() {
        return prefTravelModes;
    }
    public MeetPoint[] getMeetPoints(){
        return meetPoints;
    }
    public MeetPoint getChosenMeetPoint(){
        return chosenMeetPoint;
    }
    public String getPrefLocationType(){
        return prefLocationType;
    }
    public double[] getUserIDs(){
        return userIDs;
    }
    public int getNumOfUsers(){
        return numOfUsers;
    }
    public boolean getCalculated() {
        return calculated;
    }

    public void setTitle(String newTitle){
        title=newTitle;
    }

    public void setStartLocation(double userID, Location newLocation){
        startLocations[userIDToIndex(userID)]=newLocation;
    }

    public void setPrefTravelModes(double userID, String newPrefTravelMode) {
        prefTravelModes[userIDToIndex(userID)]=newPrefTravelMode;
    }

    public void setMeetPoints(MeetPoint[ ] newMeetPoints){
        meetPoints=newMeetPoints;
    }

    public void setChosenMeetPoint(MeetPoint newChosenMeetPoint){
        chosenMeetPoint=newChosenMeetPoint;
    }

    public void setPrefLocationType(String newLocationType){
        prefLocationType=newLocationType;
    }

    public void setUserID(double joinUserID){
            userIDs[1]=joinUserID;
            numOfUsers++;
            //assumes that the only case for setUserID is the 2nd user joining only. logic to confirm join-ability
            //is numOfUsers, which should = 1.
    }

    public void setCalculated (boolean bool) {
        calculated = bool;
    }

    private int userIDToIndex (double userID){
        if (userIDs[0]==userID){
            return 0;
        } else if (userIDs[1]==userID){
            return 1;
        }
    return -1;
    }
}