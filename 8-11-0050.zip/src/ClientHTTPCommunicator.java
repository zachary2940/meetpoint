import java.io.*;
import java.net.InetSocketAddress;
import java.util.ArrayList;

import com.sun.net.httpserver.Headers;
import jdk.nashorn.internal.runtime.ECMAException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONString;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

/**
 * do i need to keep refreshing
 */
public class ClientHTTPCommunicator {

    public static void main(String[] args) throws Exception {
        HttpServer server = HttpServer.create(new InetSocketAddress(8080), 0);
        System.out.println("Listening for connection on port 8080 ....");
        server.createContext("/meetpoint", new MyHandler());
        server.setExecutor(null); // creates a default executor
        server.start();
    }

    static class MyHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange t) throws IOException {
//            String response = "This is the response";
            System.out.println(t.getRemoteAddress() + " Server Connected");// prints out ip
            OutputStream out = t.getResponseBody(); //should i use printwriter here
//            out.write(response.getBytes()); //writes to the http page
//            System.out.println(t.getResponseBody());
//            out.close();
            //Headers h = t.getResponseHeaders();
            //h.add("Content-Type", "application/json");

            InputStreamReader isr = new InputStreamReader(t.getRequestBody(), "utf-8");
            BufferedReader br = new BufferedReader(isr);
            int b;
            StringBuilder buf = new StringBuilder(512); // From now on, the right way of moving from bytes to utf-8 characters:
            try {
                while ((b = br.read()) != -1) {
                    buf.append((char) b);
                }
            } catch (Exception e) {
                if (buf == null) {
                    System.out.println("shit");
                }
            }
//            System.out.println(buf);

            br.close();
            isr.close();
            String jsonstring = buf.toString(); //works for json
            JSONObject json = new JSONObject(jsonstring);
            System.out.println(json);
            String choice = json.getString("method");
            System.out.println(choice);
            switch (choice) {
                case "updateUser":
                    String name = json.getString("name");
//                    String userId = json.getString("userId");
                    String defaultStartAddress = json.getString("defaultStartAddress");
                    String defaultTravelMode = json.getString("defaultTravelMode");
//                    UserDetails user = new UserDetails(name, userId, new Location(defaultStartAddress), defaultTravelMode); //add and update is the same thing, will check if the user id is the same
//                    SessionManager.sm.updateUserArray(user); // got prob, nvr initialise userarr
                    String userId = SessionManager.sm.addUser(name, defaultStartAddress, defaultTravelMode);
                    print(SessionManager.sm.getUserArray());
                    print(userId);
                    print("Updated User");
                    JSONObject userDetails = new JSONObject();
                    userDetails.put("result", "O");
                    userDetails.put("userId", userId);
                    t.sendResponseHeaders(200, userDetails.toString().length());
                    out.write(userDetails.toString().getBytes());

                    break;

                case "createSession":
                    String userId_2 = json.getString("userId");
                    print("userid: " + userId_2);
                    String sessionTitle = json.getString("sessionTitle");
                    print((SessionManager.sm.getUserArray()));
//                    print((SessionManager.sm.getUserArray().get(0).getUserID()));
                    UserDetails user1 = SessionManager.sm.getUserDet(userId_2);
                    print(user1.getName());
//                    print((SessionManager.sm.getUserDet(userId_2)));
                    try{
                        print(SessionManager.sm.getUserDet(userId_2).getName()); // failed here, get userDet failed
                    }
                    catch (Exception e){
                        print(e.getMessage());
                    }
                    try {
                        print("creating session");
                        Session newSession = SessionManager.sm.createSession(sessionTitle, userId_2); // maybe user details not stored properly. YES, searching function spoil?
                        print("testing");
                        String sessionId = newSession.getSessionID();
                        UserDetails user_2 = SessionManager.sm.getUserDet(userId_2);
                        String name_2 = user_2.getName();
                        String prefTravelMode = user_2.getPrefTravelMode();
                        String prefStartLocation = user_2.getPrefStartLocation().getName();
                        user_2.addSession(sessionTitle);
                        JSONObject sessionJson = new JSONObject();
                        sessionJson.put("result", "O");
                        sessionJson.put("sessionId", sessionId);
                        sessionJson.put("U1N", name_2);
                        sessionJson.put("U1T", prefTravelMode);
                        sessionJson.put("U1A", prefStartLocation);
                        t.sendResponseHeaders(200, sessionJson.toString().length());
                        out.write(sessionJson.toString().getBytes());
                    }
                    catch (Exception e){
                        print(e.getMessage());
                    }
                    break;

                case "getSessions": //might have null pointer for get sessions

                    ArrayList<Session> sessions = SessionsLog.getSessions();//json.getDouble("userId"));
//                    if(sessions)/*get kc to put in*/
                    JSONObject OverLordList = new JSONObject();
                    OverLordList.put("result", "O");
                    System.out.println("Retrieved Sessions");
                    JSONArray sessionArray = new JSONArray();
                    for(int i=0; i<sessions.size();i++){
                        JSONObject sessionObject = new JSONObject();
                        Session sesh = sessions.get(i); // getting session object
                        String sessionId_2 = sesh.getSessionID();
                        String title = sesh.getTitle();
                        MeetPoint chosenMeetPoint = sesh.getChosenMeetPoint();
                        int meetpointIndex = sesh.getChosenMeetPointIndex(chosenMeetPoint);
                        sessionObject.put("sessionId" , sessionId_2);
                        sessionObject.put("title", title);
                        sessionObject.put("chosenMeetpoint", meetpointIndex);
                        JSONArray meetpointArray = new JSONArray();
                        JSONObject meetpointObject = new JSONObject();
                        MeetPoint[] meetPoints = sesh.getMeetPoints();
                        for(int j=0; j<meetPoints.length; j++) {
                            MeetPoint meetPoint = meetPoints[j];
                            meetpointObject.put("routeImage", meetPoint.getMeetPointImage());
                            meetpointObject.put("name", meetPoint.getName());
                            JSONObject coordinates = new JSONObject();
                            double[] coord = meetPoint.getCoordinates();
                            String lat = String.valueOf(coord[0]);
                            String lon = String.valueOf(coord[1]);
                            coordinates.put("lat", lat);
                            coordinates.put("lon", lon);
                            meetpointObject.put("coordinates", coordinates);
                            meetpointArray.put(meetpointObject);
                        }
                        sessionObject.put("meetpoints", meetpointArray);
                        sessionArray.put(sessionObject);
                    }
                    OverLordList.put("sessions", sessionArray);
                    print(OverLordList);
                    t.sendResponseHeaders(200, OverLordList.toString().length());
                    out.write(OverLordList.toString().getBytes());
                    break;


                case "joinSession":
                    String userId_4 = json.getString("userId");
                    String sessionId_2 = json.getString("sessionId");
                    Session joinedSession = SessionsLog.getSession(sessionId_2);
                    UserDetails user_3 = SessionManager.sm.getUserDet(userId_4);
                    String name_3 = user_3.getName();
                    String prefTravelMode_3 = user_3.getPrefTravelMode();
                    String prefStartLocation_3 = user_3.getPrefStartLocation().getName();
                    String sessionTitle_2 = joinedSession.getTitle();
                    MeetPoint chosenMeetpoint = joinedSession.getChosenMeetPoint();
                    int meetpointIndex = joinedSession.getChosenMeetPointIndex(chosenMeetpoint);
                    JSONObject sessionJson_2 = new JSONObject();
                    sessionJson_2.put("result", "O");
                    sessionJson_2.put("sessionId", sessionId_2);
                    sessionJson_2.put("title", sessionTitle_2);
                    sessionJson_2.put("chosenMeetpoint", meetpointIndex);
                    sessionJson_2.put("U2N", name_3);
                    sessionJson_2.put("U2T", prefTravelMode_3);
                    sessionJson_2.put("U2A", prefStartLocation_3);
                    MeetPoint[] meetPoints = joinedSession.getMeetPoints();
                    JSONObject meetpointList = new JSONObject();
                    JSONArray meetpointArray = new JSONArray();
                    for(int i=0; i<meetPoints.length; i++) {
                        JSONObject meetpointObject = new JSONObject();
                        MeetPoint meetPoint = meetPoints[i];
                        meetpointObject.put("routeImage", meetPoint.getMeetPointImage());
                        meetpointObject.put("name", meetPoint.getName());
                        JSONObject coordinates = new JSONObject();
                        double[] coord = meetPoint.getCoordinates();
                        double lat = coord[0];
                        double lon = coord[1];
                        coordinates.put("lat", lat);
                        coordinates.put("lon", lon);
                        meetpointObject.put("coordinates", coordinates);
                        meetpointArray.put(meetpointObject);
                    }
                    sessionJson_2.put("meetpoints", meetpointArray);
                    t.sendResponseHeaders(200, sessionJson_2.toString().length());
                    out.write(sessionJson_2.toString().getBytes());
                    break;

                case "deleteSession":
                    String sessionId_1 = json.getString("sessionId");
                    String userId_5 = json.getString("userId");
                    SessionManager.sm.removeSession(sessionId_1, userId_5);
                    JSONObject deleteSession = new JSONObject();
                    deleteSession.put("result", "O");
                    t.sendResponseHeaders(200, deleteSession.toString().length());
                    out.write(deleteSession.toString().getBytes());
                    break;

                case "calculate":
                    String sessionId_3 = json.getString("sessionId"); // how to get correct session
                    Session calculatedSession = SessionsLog.getSession(sessionId_3);
                    MeetPoint[] meetPoints_2 = calculatedSession.getMeetPoints();
                    JSONObject meetpointList_2 = new JSONObject();
                    JSONArray meetpointArray_2 = new JSONArray();
                    for(int i=0; i<meetPoints_2.length; i++) {
                        JSONObject meetpointObject = new JSONObject();
                        MeetPoint meetPoint = meetPoints_2[i];
                        meetpointObject.put("routeImage", meetPoint.getMeetPointImage());
                        meetpointObject.put("name", meetPoint.getName());
                        JSONObject coordinates = new JSONObject();
                        double[] coord = meetPoint.getCoordinates();
                        double lat = coord[0];
                        double lon = coord[1];
                        coordinates.put("lat", lat);
                        coordinates.put("lon", lon);
                        meetpointObject.put("coordinates", coordinates);
                        meetpointArray_2.put(meetpointObject);
                    }
                    meetpointList_2.put("result", "O");
                    meetpointList_2.put("meetpoints", meetpointArray_2);
                    t.sendResponseHeaders(200, meetpointList_2.toString().length());
                    out.write(meetpointList_2.toString().getBytes());
                    break;

                case "editSession":
                    String userId_6 = json.getString("userId");
                    String sessionId_4 = json.getString("sessionId");
                    String fieldType = json.getString("field");
                    String value = json.getString("value");
//                    SessionManager.sm.editSessInfo(userId_6, sessionId_4, field, value );

                    switch (fieldType){
                        case "LT":
                            SessionManager.sm.editSessionprefLocationType(sessionId_4, userId_6, value);
                            break;
                        case "CM":
                            SessionManager.sm.updateChosenMeetPoint(userId_6, sessionId_4, );
                            break;
                        case ""



                    }
                    JSONObject editSession = new JSONObject();
                    editSession.put("result", "O");
                    t.sendResponseHeaders(200, editSession.toString().length());
                    out.write(editSession.toString().getBytes());
                    break;

                default:
                    JSONObject defaultJSON = new JSONObject();
                    defaultJSON.put("result", "O");
                    t.sendResponseHeaders(200, defaultJSON.toString().length());
                    out.write(defaultJSON.toString().getBytes());
                }
            }
        }

    static void print(Object o) {
        System.out.println(o);
    }
}

// The resulting string is: buf.toString()
// and the number of BYTES (not utf-8 characters) from the body is: buf.length()





/**
 * http://localhost:8080/meetpoint
 *
 * JSONObject obj = new JSONObject();
 * JSONArray arr = new JSONArray();
 *
 * LEGEND (for fields):
 * LT ==> Location type
 * CM ==> chosenmeetpoint (index on meetpoints array)
 * U1A ==> address of user 1
 * U1T ==> travel mode of user 1
 * U2A ==> address of user 2
 * U2T ==> travel mode of user 2
 */