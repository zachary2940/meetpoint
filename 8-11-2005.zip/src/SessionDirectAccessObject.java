
import java.util.ArrayList;

public interface SessionDirectAccessObject {

     Session createSession(String sessionTitle, String userID);
     void updateSessionsLog(Session sess);
     void joinSession(String sessID, String userID);
     void removeSession(String sessionID, String userID);

}
